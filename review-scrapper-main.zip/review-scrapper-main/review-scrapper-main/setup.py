from setuptools import find_packages, setup

setup(
    name="scrapper",
    version="0.0.1",
    author="pwskills",
    author_email="hrisikesh.neogi@pw.live",
    packages=find_packages(),
    install_requires=[],
)