MONGODB_URL_KEY: str = "MONGO_DB_URL"
MONGO_DATABASE_NAME: str = "myntra-reviews"

SESSION_PRODUCT_KEY: str = "product_name"
