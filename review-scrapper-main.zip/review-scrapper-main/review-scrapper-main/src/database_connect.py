"""
Database connection module for MongoDB operations
"""

from pymongo import MongoClient
from typing import Optional, Dict, Any
import os

class mongo_operation:
    """
    MongoDB operation class for handling database connections and operations
    """
    
    def __init__(self, client_url: str, database_name: str):
        """
        Initialize MongoDB connection
        
        Args:
            client_url: MongoDB connection string
            database_name: Name of the database to connect to
        """
        self.client = MongoClient(client_url)
        self.db = self.client[database_name]
    
    def bulk_insert(self, data, collection_name: str):
        """
        Insert multiple documents into a collection
        
        Args:
            data: DataFrame or list of documents to insert
            collection_name: Name of the collection
        """
        collection = self.db[collection_name]
        if hasattr(data, 'to_dict'):  # Handle pandas DataFrame
            data = data.to_dict('records')
        return collection.insert_many(data)
    
    def find(self, collection_name: str, query: dict = None):
        """
        Find documents in a collection
        
        Args:
            collection_name: Name of the collection
            query: Query filter
            
        Returns:
            List of documents
        """
        if query is None:
            query = {}
        collection = self.db[collection_name]
        return list(collection.find(query))
    
    def close_connection(self):
        """Close the MongoDB connection"""
        self.client.close()
